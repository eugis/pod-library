#!/bin/bash

java -cp 'lib/jars/*' "tp4.client.Client" $*

