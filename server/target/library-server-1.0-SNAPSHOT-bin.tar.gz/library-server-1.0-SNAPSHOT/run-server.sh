#!/bin/bash

java  -cp 'lib/jars/*' "tp4.server.Server" $*

